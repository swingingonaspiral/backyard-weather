#requires -Version 5.1
<#
One-time Google Nest authorization and read-only connection check.
Windows PowerShell 5.1. No third-party modules, administrator rights, or app changes.
Only Google's OAuth token endpoint and Nest devices.list endpoint are called.
The saved credential bundle is Windows DPAPI encrypted. No telemetry is saved.
#>
[CmdletBinding()]
param()

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'
$VerbosePreference = 'SilentlyContinue'
$DebugPreference = 'SilentlyContinue'
$ProgressPreference = 'SilentlyContinue'
$script:SafeError = ''
$script:Stage = 'startup'
$exitCode = 0

function Stop-Setup([string]$Message) {
    $script:SafeError = $Message
    throw [System.InvalidOperationException]::new($Message)
}
function Get-Field($Object, [string]$Name) {
    if ($null -eq $Object) { return $null }
    $p = $Object.PSObject.Properties[$Name]
    if ($null -eq $p) { return $null }
    return $p.Value
}
function Reveal-Secure([Security.SecureString]$Value) {
    $ptr = [IntPtr]::Zero
    try {
        $ptr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($Value)
        return [Runtime.InteropServices.Marshal]::PtrToStringBSTR($ptr)
    } finally {
        if ($ptr -ne [IntPtr]::Zero) {
            [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($ptr)
        }
    }
}
function Validate-Project([string]$Project) {
    if ($Project -notmatch '^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$') {
        Stop-Setup 'Use the UUID-shaped NEST DEVICE ACCESS project ID, not the Google Cloud project name or project number.'
    }
}
function Safe-NetworkFailure($Record, [string]$Operation) {
    $status = 'not available'
    $kind = ''
    try {
        if ($null -ne $Record.Exception.Response) {
            $status = [string][int]$Record.Exception.Response.StatusCode
        }
        if ($null -ne $Record.ErrorDetails -and $Record.ErrorDetails.Message) {
            $details = $Record.ErrorDetails.Message | ConvertFrom-Json
            $candidate = Get-Field $details 'error'
            if ($candidate -is [string] -and $candidate -in @('invalid_grant','invalid_client','access_denied','invalid_scope','unauthorized_client')) {
                $kind = '; ' + $candidate
            }
        }
    } catch { }
    Stop-Setup ($Operation + ' failed (HTTP ' + $status + $kind + '). See START-HERE.txt for the matching troubleshooting step. Raw error content was not printed to avoid exposing credentials.')
}
function Request-Tokens([hashtable]$Body) {
    try {
        return Invoke-RestMethod -Uri 'https://oauth2.googleapis.com/token' -Method Post `
            -ContentType 'application/x-www-form-urlencoded' -Body $Body `
            -TimeoutSec 45 -MaximumRedirection 0 -ErrorAction Stop
    } catch { Safe-NetworkFailure $_ 'Google token exchange' }
}
function Get-Devices([string]$Project, [string]$AccessToken) {
    Validate-Project $Project
    if ([string]::IsNullOrWhiteSpace($AccessToken)) { Stop-Setup 'Google did not return an access token.' }
    try {
        return Invoke-RestMethod -Uri ('https://smartdevicemanagement.googleapis.com/v1/enterprises/' + $Project + '/devices') `
            -Method Get -Headers @{Authorization = ('Bearer ' + $AccessToken)} `
            -TimeoutSec 45 -MaximumRedirection 0 -ErrorAction Stop
    } catch { Safe-NetworkFailure $_ 'Nest device-list request' }
}
function Save-Bundle($Bundle, [string]$Directory) {
    $secure = $null
    $temp = $null
    try {
        $secure = ConvertTo-SecureString -String ($Bundle | ConvertTo-Json -Depth 5 -Compress) -AsPlainText -Force
        # Omitting -Key deliberately selects Windows DPAPI; no plaintext fallback.
        $ciphertext = ConvertFrom-SecureString -SecureString $secure
        [void][IO.Directory]::CreateDirectory($Directory)
        $name = 'nest-auth-' + [DateTime]::UtcNow.ToString('yyyyMMddTHHmmssZ') + '-' + [Guid]::NewGuid().ToString('N') + '.protected'
        $final = Join-Path -Path $Directory -ChildPath $name
        $temp = $final + '.tmp'
        [IO.File]::WriteAllText($temp, $ciphertext, [Text.UTF8Encoding]::new($false))
        [IO.File]::Move($temp, $final)
        return $final
    } finally {
        if ($null -ne $secure) { $secure.Dispose() }
        if ($temp -and [IO.File]::Exists($temp)) { [IO.File]::Delete($temp) }
    }
}
function Load-Bundle([string]$Path) {
    $secure = $null
    try {
        $secure = ConvertTo-SecureString -String ([IO.File]::ReadAllText($Path).Trim())
        return ((Reveal-Secure $secure) | ConvertFrom-Json)
    } catch {
        Stop-Setup 'Cannot decrypt the saved setup bundle. Use the same Windows account on the same computer that authorized it. Otherwise choose A to authorize here.'
    } finally {
        if ($null -ne $secure) { $secure.Dispose() }
    }
}
function Choose-ClientJson {
    Add-Type -AssemblyName System.Windows.Forms
    $dialog = New-Object System.Windows.Forms.OpenFileDialog
    try {
        $dialog.Title = 'Select the OAuth client JSON you downloaded from Google Cloud'
        $dialog.Filter = 'Google OAuth credentials (*.json)|*.json'
        $dialog.CheckFileExists = $true
        $dialog.Multiselect = $false
        if ($dialog.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK) { Stop-Setup 'File selection cancelled. No authorization request was made.' }
        return $dialog.FileName
    } finally { $dialog.Dispose() }
}
function Read-AuthorizationCode([string]$ExpectedState) {
    $secure = $null
    try {
        Write-Host ''
        Write-Host 'In the browser, approve your home and thermostat permissions.'
        Write-Host 'After Google redirects to www.google.com, copy the ENTIRE address bar URL.'
        Write-Host 'Paste it below. It will be masked because it contains a one-use authorization code.'
        $secure = Read-Host 'Paste the complete returned URL, then press Enter' -AsSecureString
        $text = (Reveal-Secure $secure).Trim()
        $uri = $null
        if (-not [Uri]::TryCreate($text, [UriKind]::Absolute, [ref]$uri)) { Stop-Setup 'Paste the entire redirected Google URL, not just the authorization code.' }
        if ($uri.Scheme -ne 'https' -or $uri.DnsSafeHost -ne 'www.google.com' -or $uri.Port -ne 443 -or $uri.UserInfo -or $uri.AbsolutePath -ne '/') {
            Stop-Setup 'The returned address is not the registered https://www.google.com redirect. Check the redirect in Google Cloud and authorize again.'
        }
        Add-Type -AssemblyName System.Web
        $query = [System.Web.HttpUtility]::ParseQueryString($uri.Query)
        if ($query['error']) { Stop-Setup 'Google returned an authorization error. Check that you chose your Nest Google account and granted the requested home/thermostat access, then retry.' }
        if (@($query.GetValues('state')).Count -ne 1 -or -not [String]::Equals($query['state'], $ExpectedState, [StringComparison]::Ordinal)) {
            Stop-Setup 'Authorization state does not match this run. Use the link opened by this run, not a link or return URL from a previous attempt.'
        }
        if (@($query.GetValues('code')).Count -ne 1 -or [string]::IsNullOrWhiteSpace($query['code'])) { Stop-Setup 'No single authorization code was found in the returned URL. Start authorization again and copy the final address before navigating away.' }
        return $query['code']
    } finally { if ($null -ne $secure) { $secure.Dispose() } }
}
function Show-Thermostats($Reply) {
    $devices = @(Get-Field $Reply 'devices')
    $thermostats = @($devices | Where-Object { (Get-Field $_ 'type') -eq 'sdm.devices.types.THERMOSTAT' })
    Write-Host ''
    Write-Host 'Device-list request succeeded. The initial authorization trigger is complete.' -ForegroundColor Green
    if ($thermostats.Count -eq 0) {
        Write-Host 'No thermostat was returned. Review the Google account and selected device permissions in Partner Connections Manager.' -ForegroundColor Yellow
        return
    }
    Write-Host ('Thermostats returned: ' + $thermostats.Count)
    foreach ($device in $thermostats) {
        $traits = Get-Field $device 'traits'
        $info = Get-Field $traits 'sdm.devices.traits.Info'
        $label = [string](Get-Field $info 'customName')
        if ([string]::IsNullOrWhiteSpace($label)) { $label = 'Nest thermostat' }
        $label = $label -replace '[\p{C}]', ''
        Write-Host ('Device: ' + $label)
        Write-Host ('Resource ID: ' + [string](Get-Field $device 'name'))
        $hvac = Get-Field (Get-Field $traits 'sdm.devices.traits.ThermostatHvac') 'status'
        if ([string]::IsNullOrWhiteSpace([string]$hvac)) { $hvac = 'Unavailable - check permissions' }
        Write-Host ('HVAC status: ' + $hvac)
        $temp = Get-Field (Get-Field $traits 'sdm.devices.traits.Temperature') 'ambientTemperatureCelsius'
        if ($null -ne $temp) { Write-Host ('Thermostat temperature: {0:F1} F' -f (([double]$temp * 9.0 / 5.0) + 32.0)) }
        Write-Host ''
    }
    Write-Host 'Next: inspect Pub/Sub messages for a ThermostatHvac status change.'
    Write-Host 'No thermostat settings were changed. No sensor history was saved by this tester.'
}

try {
    if ($env:OS -ne 'Windows_NT') { Stop-Setup 'Run this setup tool on Windows, using START-NEST-SETUP.cmd.' }
    if ([string]::IsNullOrWhiteSpace($env:LOCALAPPDATA)) { Stop-Setup 'LOCALAPPDATA is unavailable. Use your normal Windows account, not an administrator or service account.' }
    [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12
    $directory = Join-Path -Path $env:LOCALAPPDATA -ChildPath 'BackyardWeather\NestSetup'
    Write-Host 'Backyard Weather - separate Nest authorization and connection tester'
    Write-Host 'A: authorize using your downloaded OAuth JSON. R: retest a saved setup. Q: exit.'
    Write-Host 'This does not install the Nest integration in the weather application.'
    $choice = (Read-Host 'Choose A, R, or Q').Trim().ToUpperInvariant()
    if ($choice -eq 'Q') { exit 0 }
    if ($choice -notin @('A','R')) { Stop-Setup 'Choose A to authorize, or R to retest a saved authorization.' }
    if ($choice -eq 'A') {
        $script:Stage = 'reading the OAuth JSON'
        $path = Choose-ClientJson
        if ((Get-Item -LiteralPath $path).Length -gt 1048576) { Stop-Setup 'That file is too large to be the OAuth client credentials JSON.' }
        $config = Get-Content -LiteralPath $path -Raw -Encoding UTF8 | ConvertFrom-Json
        $client = Get-Field $config 'web'
        if ($null -eq $client) { Stop-Setup 'Select the Web application OAuth client JSON, not a service-account key or desktop-client file.' }
        $clientId = [string](Get-Field $client 'client_id')
        $clientSecret = [string](Get-Field $client 'client_secret')
        if ($clientId -notmatch '^[a-zA-Z0-9_.-]+\.apps\.googleusercontent\.com$' -or [string]::IsNullOrWhiteSpace($clientSecret)) { Stop-Setup 'The selected JSON does not contain the required web client ID and client secret.' }
        $project = (Read-Host 'Nest DEVICE ACCESS project ID (the UUID, not the Cloud project ID)').Trim()
        Validate-Project $project
        Write-Host ('Google Cloud project from JSON: ' + [string](Get-Field $client 'project_id'))
        Write-Host ('Nest Device Access project: ' + $project)
        Write-Host 'Google must have this OAuth client ID linked to that Device Access project.'
        Write-Host 'Authorized redirect URI must be exactly https://www.google.com'
        if ((Read-Host 'Open Google to authorize, exchange tokens, and list your devices? Type YES').Trim() -cne 'YES') { Stop-Setup 'Cancelled before contacting Google.' }
        $script:Stage = 'browser authorization'
        $rng = [Security.Cryptography.RandomNumberGenerator]::Create()
        try { $bytes = New-Object byte[] 32; $rng.GetBytes($bytes); $state = ([BitConverter]::ToString($bytes)).Replace('-','').ToLowerInvariant() } finally { $rng.Dispose() }
        $arguments = [ordered]@{
            redirect_uri = 'https://www.google.com'; access_type = 'offline'; prompt = 'consent';
            client_id = $clientId; response_type = 'code'; scope = 'https://www.googleapis.com/auth/sdm.service'; state = $state
        }
        $queryString = (($arguments.GetEnumerator() | ForEach-Object { [Uri]::EscapeDataString([string]$_.Key) + '=' + [Uri]::EscapeDataString([string]$_.Value) }) -join '&')
        $url = 'https://nestservices.google.com/partnerconnections/' + $project + '/auth?' + $queryString
        Write-Host 'Opening your default browser. The authorization link is also below (it contains no client secret).'
        Write-Host $url
        Start-Process -FilePath $url
        $code = Read-AuthorizationCode $state
        $script:Stage = 'exchanging the one-use code'
        $tokens = Request-Tokens @{client_id=$clientId; client_secret=$clientSecret; code=$code; grant_type='authorization_code'; redirect_uri='https://www.google.com'}
        $refresh = [string](Get-Field $tokens 'refresh_token')
        $access = [string](Get-Field $tokens 'access_token')
        if ([string]::IsNullOrWhiteSpace($refresh) -or [string]::IsNullOrWhiteSpace($access)) { Stop-Setup 'Google did not return both tokens. No incomplete credential bundle was saved. Repeat authorization with consent.' }
        $script:Stage = 'encrypting the authorization locally'
        $bundle = [pscustomobject]@{
            format='backyard-weather-nest-setup-v1'; device_access_project_id=$project;
            google_cloud_project_id=[string](Get-Field $client 'project_id'); client_id=$clientId;
            client_secret=$clientSecret; refresh_token=$refresh; redirect_uri='https://www.google.com';
            authorized_at_utc=[DateTime]::UtcNow.ToString('o')
        }
        $saved = Save-Bundle $bundle $directory
        Write-Host ('Saved encrypted authorization: ' + $saved)
        Write-Host 'Keep this local. Do not upload it or copy it between computers.'
    } else {
        $script:Stage = 'opening the saved authorization'
        if (-not (Test-Path -LiteralPath $directory -PathType Container)) { Stop-Setup 'No saved setup exists here yet. Run again and choose A.' }
        $files = @(Get-ChildItem -LiteralPath $directory -Filter 'nest-auth-*.protected' -File | Sort-Object LastWriteTimeUtc -Descending)
        if ($files.Count -eq 0) { Stop-Setup 'No saved authorization file was found. Run again and choose A.' }
        $saved = $files[0].FullName
        $bundle = Load-Bundle $saved
        if ((Get-Field $bundle 'format') -ne 'backyard-weather-nest-setup-v1') { Stop-Setup 'Unsupported setup file format.' }
        $project = [string](Get-Field $bundle 'device_access_project_id')
        Validate-Project $project
        $clientId = [string](Get-Field $bundle 'client_id')
        $clientSecret = [string](Get-Field $bundle 'client_secret')
        $refresh = [string](Get-Field $bundle 'refresh_token')
        if ([string]::IsNullOrWhiteSpace($clientId) -or [string]::IsNullOrWhiteSpace($clientSecret) -or [string]::IsNullOrWhiteSpace($refresh)) { Stop-Setup 'The saved authorization is incomplete. Authorize again.' }
        Write-Host ('Retesting newest saved authorization for Device Access project: ' + $project)
        if ((Read-Host 'Refresh the access token and list devices now? Type YES').Trim() -cne 'YES') { Stop-Setup 'Cancelled before contacting Google.' }
        $script:Stage = 'refreshing the access token'
        $tokens = Request-Tokens @{client_id=$clientId; client_secret=$clientSecret; refresh_token=$refresh; grant_type='refresh_token'}
        $access = [string](Get-Field $tokens 'access_token')
    }
    $script:Stage = 'listing Nest devices'
    $reply = Get-Devices $project $access
    Show-Thermostats $reply
} catch {
    $exitCode = 1
    Write-Host ''
    Write-Host ('Setup stopped during: ' + $script:Stage) -ForegroundColor Yellow
    if ($script:SafeError) { Write-Host $script:SafeError }
    else { Write-Host 'A local or network operation failed. No raw exception or token was printed. Share only the stage above, not your credential JSON or authorization URL.' }
    Write-Host 'Existing weather records, provider keys, and application settings were not modified.'
} finally {
    # This is not a guarantee of erasure from managed memory; nothing is written as plaintext.
    $access = $null; $refresh = $null; $clientSecret = $null; $code = $null
    $tokens = $null; $bundle = $null; $config = $null; $client = $null; $reply = $null
}
exit $exitCode
